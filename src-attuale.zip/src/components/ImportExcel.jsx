import * as XLSX from 'xlsx'
import { supabase } from '../lib/supabase'

export default function ImportExcel() {
    function parseAttrezzatura(text = '') {

        const value = text.toUpperCase()
      
        let lettini = 0
        let sdraio = 0
        let regista = 0
      
        const regex = /(\d+)\s*([LSR])/g
      
        let match
      
        while ((match = regex.exec(value)) !== null) {
      
          const qty = Number(match[1])
          const type = match[2]
      
          if (type === 'L') lettini += qty
          if (type === 'S') sdraio += qty
          if (type === 'R') regista += qty
        }
      
        return {
          lettini,
          sdraio,
          regista,
        }
      }

    const handleFile = async (e) => {

        const file = e.target.files[0]

        if (!file) return

        const data = await file.arrayBuffer()

        const workbook = XLSX.read(data)

        const sheet = workbook.Sheets[workbook.SheetNames[0]]

        const rows = XLSX.utils.sheet_to_json(sheet)
        alert(JSON.stringify(rows[0]))

        console.log(rows)

        const formatted = rows.map(row => {

            const attrezzatura = parseAttrezzatura(
              row['Attrezzatura'] || ''
            )
          
            const isOmbrellone = !!row['Numero Ombrellone']
          
            return {
          
              tipo: isOmbrellone
                ? 'ombrellone'
                : 'palma',
          
              numero: isOmbrellone
                ? row['Numero Ombrellone']
                : row['Numero Palma'],
          
              cliente: row['Cliente'],
          
              stato: 'occupato',
          
              lettini: attrezzatura.lettini,
          
              sdraio: attrezzatura.sdraio,
          
              regista: attrezzatura.regista,
            }
          })

        const { error } = await supabase
            .from('occupazioni')
            .insert(formatted)

        if (error) {
            console.error(error)
            alert('Errore importazione')
            return
        }

        alert('Importazione completata!')
    }

    return (
        <div className="card">

            <h3 style={{ marginBottom: 20 }}>
                Importa Excel Occupazioni
            </h3>

            <input
                type="file"
                accept=".xlsx,.csv"
                onChange={handleFile}
            />

        </div>
    )
}