import { useState, useMemo } from 'react'
import Modal from '../components/Modal'
import { fmtEur, uid } from '../lib/data'

export default function Clienti({ db, onSalvaCliente, showToast }) {
  const { postazioni } = db
  const [search, setSearch] = useState('')
  const [modalOpen, setModalOpen] = useState(false)
  const [form, setForm] = useState({})

  const lista = useMemo(() => {

    const q = search.toLowerCase()
  
    return postazioni.filter(p => {
  
      if (!p.cliente) return false
  
      return `
        ${p.cliente}
        ${p.tipo}
        ${p.numero}
      `
        .toLowerCase()
        .includes(q)
    })
  
  }, [postazioni, search])

  function openNuovo() {
    setForm({ nome: '', cognome: '', telefono: '', email: '', note: '' })
    setModalOpen(true)
  }
  function openEdit(c) {
    setForm({ ...c })
    setModalOpen(true)
  }
  function set(k, v) { setForm(f => ({ ...f, [k]: v })) }

  function handleSalva() {
    if (!form.nome || !form.cognome) { showToast('Nome e cognome obbligatori', 'error'); return }
    onSalvaCliente({ ...form, id: form.id || uid() })
    showToast(form.id ? 'Cliente aggiornato ✓' : 'Cliente aggiunto ✓')
    setModalOpen(false)
  }

  return (
    <div className="page-content">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, flexWrap: 'wrap', gap: 8 }}>
        <h1 className="page-title" style={{ marginBottom: 0 }}>Gestione Clienti</h1>
        <button className="btn btn-yellow" onClick={openNuovo}>+ Nuovo Cliente</button>
      </div>

      <div className="search-bar">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cerca per nome, telefono, email..." />
      </div>

      <div className="tbl-wrap">
        <table>
          <thead>
            <tr><th>Cliente</th><th>Postazione</th><th>Attrezzatura</th><th>Stato</th><th></th></tr>
          </thead>
          <tbody>
            {lista.length === 0 ? (
              <tr><td colSpan={8} style={{ textAlign: 'center', padding: 28, color: 'var(--muted)' }}>Nessun cliente trovato.</td></tr>
            ) : lista.map(c => (
              <tr key={c.id}>

  <td style={{ fontWeight: 700 }}>
    {c.cliente}
  </td>

  <td>
    {c.tipo} {c.numero}
  </td>

  <td>
    {c.lettini || 0}L {' '}
    {c.sdraio || 0}S {' '}
    {c.regista || 0}R
  </td>

  <td>
    <span className="badge badge-red">
      Occupato
    </span>
  </td>

</tr>
            
          ))}
          </tbody>
        </table>
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={form.id ? `${form.nome} ${form.cognome}` : 'Nuovo Cliente'} size="modal-sm">
        <div className="form-row">
          <div className="form-group"><label>Nome</label><input value={form.nome || ''} onChange={e => set('nome', e.target.value)} /></div>
          <div className="form-group"><label>Cognome</label><input value={form.cognome || ''} onChange={e => set('cognome', e.target.value)} /></div>
        </div>
        <div className="form-row">
          <div className="form-group"><label>Telefono</label><input type="tel" value={form.telefono || ''} onChange={e => set('telefono', e.target.value)} /></div>
          <div className="form-group"><label>Email</label><input type="email" value={form.email || ''} onChange={e => set('email', e.target.value)} /></div>
        </div>
        <div className="form-row single">
          <div className="form-group"><label>Note</label><textarea value={form.note || ''} onChange={e => set('note', e.target.value)} placeholder="Es. porta cane, allergia sole, cliente storico..." /></div>
        </div>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 8 }}>
          <button className="btn btn-outline" onClick={() => setModalOpen(false)}>Annulla</button>
          <button className="btn btn-primary" onClick={handleSalva}>💾 Salva</button>
        </div>
      </Modal>
    </div>
  )
}
